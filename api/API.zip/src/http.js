import App from "./app"

const server = App.server
const io = App.io

export {server, io};
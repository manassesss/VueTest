import {Sequelize, Model} from "sequelize";

export default class Doctor extends Model {
    static init(sequelize) {
        super.init({
            name: {
                type: Sequelize.STRING,
                defaultValue: '',
                validate: {
                    len: {
                        args: [3, 255],
                        msg: "Campo nome deve ter entre 3 e 255 caracteres."
                    }
                }
            },
            field: {
                type: Sequelize.STRING,
                defaultValue: '',
                unique: {
                    msg: "Email já existe!"
                },
                validate: {
                    isEmail: {
                        msg: "Email inválido!"
                    }
                },
            },
        },{
            sequelize
        });
        return this;
    }

    static associate(models){
        this.hasMany(models.Appointments, { foreignKey: 'user_id' });
    }
    
}